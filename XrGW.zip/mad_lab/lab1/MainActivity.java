package com.example.lab;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int fontsize = 25;
    int colourIdx = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView text = findViewById(R.id.textView);
        Button sizeButton = findViewById(R.id.sizeButton);
        Button colorButton = findViewById(R.id.colourButton);

        sizeButton.setOnClickListener((v) -> {
            text.setTextSize(fontsize);
            fontsize += 5;
            if(fontsize > 40) fontsize = 20;
        });

        colorButton.setOnClickListener((v) -> {
            String[] colors = {"#0000ff", "#00ff00", "#ff0000", "#000000"};
            text.setTextColor(Color.parseColor(colors[colourIdx]));
            colourIdx++;
            if(colourIdx > 3) colourIdx = 0;
        });

    }
}
