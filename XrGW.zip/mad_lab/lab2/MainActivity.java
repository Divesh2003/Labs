package com.example.lab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText unameText = findViewById(R.id.username);
        EditText pwdText = findViewById(R.id.password);
        Button clearBtn = findViewById(R.id.clearButton);
        Button loginBtn = findViewById(R.id.loginButton);

        clearBtn.setOnClickListener((v) -> {
            unameText.setText("");
            pwdText.setText("");
        });

        loginBtn.setOnClickListener((v) -> {
            String uname = unameText.getText().toString();
            String passwd = pwdText.getText().toString();
            if(uname.length() == 0 || passwd.length() == 0){
                Toast.makeText(getBaseContext(), "Enter both field", Toast.LENGTH_SHORT).show();
            }
            else if(uname.equals("admin") && passwd.equals("admin")){
                Toast.makeText(getBaseContext(), "All good, loggin in", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(getBaseContext(), "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
