package com.example.lab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText num1, num2, result;

    protected void calc(char op){
        float n1 = Float.parseFloat(num1.getText().toString());
        float n2 = Float.parseFloat(num2.getText().toString());
        float res = 0;
        if(op == '+') res = n1 + n2;
        if(op == '-') res = n1 - n2;
        if(op == '*') res = n1 * n2;
        if(op == '/') res = n1 / n2;
        result.setText(String.valueOf(res));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        result = findViewById(R.id.result);
        findViewById(R.id.add).setOnClickListener((v)->calc('+'));
        findViewById(R.id.sub).setOnClickListener((v)->calc('-'));
        findViewById(R.id.mul).setOnClickListener((v)->calc('*'));
        findViewById(R.id.div).setOnClickListener((v)->calc('/'));
    }
}
